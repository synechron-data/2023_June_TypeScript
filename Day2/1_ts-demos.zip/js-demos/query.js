var toy1 = new Object();
var toy2 = new Object();

// toy1.color = "red";
// toy1.shape = "circle";

Object.prototype.color = "red";
Object.prototype.shape = "circle";

console.log("Toy 1, color is:", toy1.color);
console.log("Toy 1, shape is:", toy1.shape);

console.log("Toy 2, color is:", toy2.color);
console.log("Toy 2, shape is:", toy2.shape);

console.log(toy1);
console.log(toy2);
// console.log(Object.prototype === toy1.__proto__);
// console.log(Object.prototype === toy2.__proto__);
// console.log(toy1.__proto__ === toy2.__proto__);

toy2.color = "blue";
toy2.shape = "square";

console.log("Toy 1, color is:", toy1.color);
console.log("Toy 1, shape is:", toy1.shape);

console.log("Toy 2, color is:", toy2.color);
console.log("Toy 2, shape is:", toy2.shape);

console.log(toy1);
console.log(toy2);