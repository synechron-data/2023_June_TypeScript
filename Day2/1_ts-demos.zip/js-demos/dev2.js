var dev2;

(function (ns) {
    function hello() {
        console.log("Hello from Dev 2");
    }

    ns.hello = hello;
})(dev2 = dev2 || {});