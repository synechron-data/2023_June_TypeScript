// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// class Person implements IPerson {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }
// }

// let p1: IPerson = new Person("Abhijeet", 40);
// let p2: IPerson = new Person("Ramakant", 41);

// console.log(p1.greet("Hi"));
// console.log(p2.greet("Hi"));

// ------------------------------------------------- Multiple Interface Implementations

// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee {
//     doWork(): string;
// }

// class Person implements IPerson, IEmployee {
//     constructor(public name: string, public age: number) { }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }

//     greet(message: string): string {
//         return "Hello";
//     }
// }

// let p1: Person = new Person("Abhijeet", 40);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// // ------------------------------------------------- Interface Extraction

// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee {
//     doWork(): string;
// }

// interface ICustomer {
//     doShopping(): string;
// }

// class Person implements IPerson, IEmployee, ICustomer {
//     constructor(public name: string, public age: number) { }

//     doShopping(): string {
//         return "Let us do it online";
//     }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }

//     greet(message: string): string {
//         return "Hello";
//     }
// }

// let p1: Person = new Person("Abhijeet", 40);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());
// console.log(p1.doShopping());

// // Interface Extraction
// let p2: IPerson = new Person("Abhijeet", 40);
// console.log(p2.greet("Hi"));

// let p3: IEmployee = new Person("Abhijeet", 40);
// console.log(p3.doWork());

// let p4: ICustomer = new Person("Abhijeet", 40);
// console.log(p4.doShopping());

// ------------------------------------------------- Interface Extension - Interface can extend other Interface(s)

// interface IPerson {
//     name: string;
//     age: number;
//     greet(message: string): string;
// }

// interface IEmployee extends IPerson {
//     doWork(): string;
// }

// interface ICustomer extends IPerson {
//     doShopping(): string;
// }

// class Person implements IPerson, IEmployee, ICustomer {
//     constructor(public name: string, public age: number) { }

//     doShopping(): string {
//         return "Let us do it online";
//     }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }

//     greet(message: string): string {
//         return "Hello";
//     }
// }

// let p1: IEmployee = new Person("Abhijeet", 40);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// let p2: ICustomer = new Person("Abhijeet", 40);
// console.log(p2.greet("Hi"));
// console.log(p2.doShopping());

// --------------------------------------------------- Interface can extend from class(es)

// class Control {
//     get ControlId(): number {
//         return 10;
//     }

//     focus(): string {
//         return "The control is in focus....";
//     }
// }

// class SelectableControl {
//     select(): string {
//         return "the control is selected....";
//     }
// }

// // When an interface extends a class, it extends only the class members but not 
// // their implementation because interfaces don’t contain implementations.
// interface ISelectableControls extends Control, SelectableControl { }

// class Button implements ISelectableControls {
//     get ControlId(): number {
//         throw new Error("Method not implemented.");
//     }

//     focus(): string {
//         throw new Error("Method not implemented.");
//     }

//     select(): string {
//         throw new Error("Method not implemented.");
//     }
// }

// ----------------------------------------------------------------------------

// Why we create a class?

// class Dev {
//     applyLeave() {

//     }
// }

// class Manager {
//     approveLeave() {

//     }
// }

// interface IDevMan extends Dev, Manager {}

// class DevMan implements IDevMan {
//     applyLeave(): void {
//         throw new Error("Method not implemented.");
//     }
//     approveLeave(): void {
//         throw new Error("Method not implemented.");
//     }
// }