import { IPoint, Point } from './point.js';

let point: IPoint = new Point(2, 3);
console.log(point.getDistance());