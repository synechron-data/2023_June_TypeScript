// // function hello() {
// //     console.log("Hello World!");
// // }

// // // var r = hello();
// // // console.log(r);
// // // console.log(typeof r);

// // var r1: undefined;
// // // r1 = 10;                    // Type '10' is not assignable to type 'undefined'
// // r1 = undefined;
// // console.log(r1);

// // var r2: void;
// // // r2 = 10;                    // Type 'number' is not assignable to type 'void'
// // // r2 = undefined;
// // r2 = void 0;
// // console.log(r2);

// // var r3: never;
// // // r3 = 10;                    // Type 'number' is not assignable to type 'never'
// // // r3 = undefined;             // Type 'undefined' is not assignable to type 'never'
// // console.log(r3);

// // var r4: unknown;
// // console.log(r4.trim());         // Property 'trim' does not exist on type 'unknown'

// // var r5: any;
// // console.log(r5.trim());

// // // JAVASCRIPT - undefined / void
// // // TYPESCRIPT - any / unknown / never

// // ----------------------------------------------

// // function iterate() {
// //     let i = 1;
// //     while (true) {
// //         console.log(++i);
// //     }
// // }

// function iterate(): never {
//     let i = 1;
//     while (true) {
//         console.log(++i);
//     }
// }

// function hello() {
//     console.log("Hello");
// }

// iterate();
// console.log("Last Line in the file...");

// // never in TypeScript is for expressing scenarios where certain values or behaviors are expected to never occur. 

// ------------------------------------------------------

// Function Declaration
function add1(x: number, y: number): number {
    return x + y;
}

// Function Expression
const add2 = function (x: number, y: number): number {
    return x + y;
}

// let add3;
// let add3: () => void;
let add3: (a: number, b: number) => number;
add3 = function (x: number, y: number): number {
    return x + y;
}

let add4: (a: number, b: number) => number;
add4 = function (x, y) {
    return x + y;
}

// Multiline Lambda
let add5: (a: number, b: number) => number;
add5 = (x, y) => {
    return x + y;
}

// Singleline Lambda
let add6: (a: number, b: number) => number;
add6 = (x, y) => x + y;

console.log(add1(2, 3));
console.log(add2(2, 3));
console.log(add3(2, 3));
console.log(add4(2, 3));
console.log(add5(2, 3));
console.log(add6(2, 3));

// Write a function to log a message passed and throw exception to terminate the execution

// var app: any;
// app.get('/index', (req: any, res: any) => {
//     try {
//         // Database Call
//     } catch (err) {
//         logAndTerminate(err, req, res);
//         console.log("Some Code to run after send");
//     }
// });

// function logAndTerminate(err: any, req: any, res:any): never {
//     console.log(err);  // Logger Service

//     res.status(500).json({
//         error: 'Internal Server Error',
//         message: 'Server Error Occored...'
//     });         // Send the JSON response to the client

//     throw err;          // Throw the error to terminate the execution flow
// }