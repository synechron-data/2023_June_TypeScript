function hello_js(name) {
    console.log("Hello,", name);
}

hello_js("Manish");
hello_js(10);
hello_js("Abhijeet", "Pune");
hello_js();