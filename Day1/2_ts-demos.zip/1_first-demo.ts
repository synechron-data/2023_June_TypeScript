class Program {
    public static main(arg: string): void {
        console.log(`Hello, ${arg}`);
    }
}

Program.main('Synechron');